---
name: Feature request
about: Request a feature or enhancement to eza
title: 'feat:  '
labels: ''
assignees: ''

---


